
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blogs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title_ne` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `highlight` text COLLATE utf8_unicode_ci,
  `views` int(10) unsigned NOT NULL,
  `likes` int(10) unsigned NOT NULL,
  `tags` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `published` tinyint(1) NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `thumb` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blogs_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
INSERT INTO `blogs` VALUES (9,'20 Girls Graduated From Tailoring School','','<p>\r\n\r\n</p><p>Girls and women graduated from the tailoring school. Due to the poverty and unavailability of employment services, Nepal is marked as a highly risked country for girls and women. Thousands of them are already sold in local sex trade markets and in the abroad. The chain of the human trafficking agents is being stronger day by day. Many times, some political and other support keeps the law under the agents. Many organizations including the GHF are working hard to eliminate this social problem which is totally against the humanity. Girls and&nbsp;women choose the option to work in the cities or in the abroad instead of living poor life in their own village. They want to leave their village just because they want to work, earn and support their family. Knowing this situation, the GHF has been conducting skill development trainings in many locations over the last few years. 20 girls and women are recently graduated from the 6 months tailoring school in Chitwan Nepal. Gentle Heart Foundation, a nonprofit social based organization conducted this training to strengthen girls and women financially. Gentle Heart Foundation hopes that the graduates will be able to earn and support their family as they have got an income generating skill now. Mr. Ramhari Nyaupane, Social development officer of District Development Committee Chitwan was the chief guest of the graduation program. He thanks the GHF for working in the needed community. He praised the GHF for its transparent works. All the graduates are excited gaining this skill and are planning to start their own tailoring shop or sewing and cutting job.</p><br>\r\n<br><p></p>','',39,0,'',1,'assets/images/blog/1489932324.jpg','assets/images/blog/thumb_1489932324.jpg',0,'2016-02-06 05:04:49','2017-04-30 23:15:19'),(10,'GHF Provided Scholarship for 20 Children in Co-ordinatioon with DDC, Kathmandu','','<p>\r\n\r\n</p><p>District Development Committee Office, Kathmandu has organized Scholarship Distribution Program on May 29, 2016 and provided scholarship. Gentle Heart Foundation provided scholarship for 20 vulnerable children who are from community/public schools &amp; colleges. Honorable State-Minister, Kunti Kumari Shahi inaugurated the program, the meeting was chaired by Local Development Officer and Chief District Officer of Kathmandu was the Special Guest as well as other dignitaries were present. 189 children got the scholarship during the function. We wish all the very best for these and many other children for their better future.</p><br>\r\n<br><p></p>','',4,0,'',1,'assets/images/blog/1489932491.jpg','assets/images/blog/thumb_1489932491.jpg',0,'2016-05-21 05:05:19','2017-03-21 07:11:02');
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `boards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `boards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `designation` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `bio` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `boards_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `boards` WRITE;
/*!40000 ALTER TABLE `boards` DISABLE KEYS */;
INSERT INTO `boards` VALUES (2,'Mrs. Ganga Manandhar','Vice- Chair','','Kathmandu','','assets/images/board/1489938418.jpg',90,0,'2017-03-15 04:39:18','2017-03-19 10:01:58'),(4,'Mrs. Tabita Neupane Tamang','Treasurer','','Siphal, Kathmandu','','assets/images/board/1489938398.jpg',55,0,'2017-03-15 04:41:08','2017-03-19 10:01:39'),(5,'Mr. Lakpa Lama','Board Chair','','Kathmandu','','assets/images/board/1489938409.jpg',99,0,'2017-03-15 04:45:58','2017-03-20 09:33:37'),(6,'Mrs. Nirmala Gurung','Member','','Kathmandu','','assets/images/board/1489938643.jpg',50,0,'2017-03-19 10:05:43','2017-03-19 10:05:43'),(7,'Dr. Pradeep Shrestha','Member','','Kathmandu','','assets/images/board/1489938756.jpg',45,0,'2017-03-19 10:07:36','2017-03-19 10:07:36'),(8,'Mr. Prem Kumar Bimali','member','','Kathmandu','','assets/images/board/1489938801.jpg',40,0,'2017-03-19 10:08:21','2017-03-19 10:08:21'),(9,'Ms. Madhu Tamang','Member','','Kathmandu','','assets/images/board/1489938835.jpg',35,0,'2017-03-19 10:08:56','2017-03-19 10:08:56'),(10,'Mrs. Jemini KC','Member','','Kathmandu','','assets/images/board/1489938865.jpg',20,0,'2017-03-19 10:09:25','2017-03-19 10:09:25'),(11,'Mr. Jagadish Pokharel','Secretary','9861908668','Kathmandu','','assets/images/board/1490023059.jpg',70,0,'2017-03-20 09:30:34','2017-03-20 09:32:39');
/*!40000 ALTER TABLE `boards` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `childrens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `childrens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `designation` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `bio` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `boards_id_index` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `childrens` WRITE;
/*!40000 ALTER TABLE `childrens` DISABLE KEYS */;
/*!40000 ALTER TABLE `childrens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `churches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `churches` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pastors_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pastors_phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `registered_on` datetime NOT NULL,
  `valid_till` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `churches_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `churches` WRITE;
/*!40000 ALTER TABLE `churches` DISABLE KEYS */;
INSERT INTO `churches` VALUES (1,'Sirdi Church','Chhepetar, Gorkha','06415245','www.sirdi.org','sirdi@gmail.com','Mohan Tamang','9845215','lorem sadjjs hskka dncue sklkad dnjkkjd nnc id sjdmc.','2016-10-19 00:00:00','2017-10-19 00:00:00',1,'2016-10-15 03:39:02','2016-10-15 03:39:02'),(2,'Nepali Isai Mandali','Gongabu, Kathmandu','014425715','www.nim.org','nim_gongabu@gmail.com','Barnabas Shrestha','9841257465','Leaders name ,description, location or other stuffs about church','2016-10-19 00:00:00','2017-10-19 00:00:00',1,'2016-10-15 03:42:47','2016-10-15 03:42:47'),(3,'Chhoprak Church','Chhoprak-8, Gorkha','064-15245','www.chhoprakchurch.org','cchurchi@gmail.com','Shiva Devkota','9845215','lorem sadjjs hskka dncue sklkad dnjkkjd nnc id sjdmc.','2016-10-19 00:00:00','2017-10-19 00:00:00',1,'2016-10-15 03:43:56','2016-10-29 11:55:23'),(4,'Mahendranagar Church','Kanchanpur','984521545','','','Mahesh Gautam','9845154222','','2016-10-11 00:00:00','2016-10-13 00:00:00',5,NULL,NULL),(5,'Swekshya Church','Kalimati','984521545','','','Shyam pal','9845154222','','2016-10-11 00:00:00','2016-10-13 00:00:00',5,NULL,NULL),(6,'Mahendranagar Church','Kanchanpur','984521545','','','Mahesh Gautam','9845154222','','2016-10-11 00:00:00','2016-10-13 00:00:00',5,NULL,NULL),(7,'Mahendranagar Church','Kanchanpur','984521545','','','Mahesh Gautam','9845154222','','2016-10-11 00:00:00','2016-10-13 00:00:00',5,NULL,NULL),(8,'Mahendranagar Church','Kanchanpur','984521545','','','Mahesh Gautam','9845154222','','2016-10-11 00:00:00','2016-10-13 00:00:00',5,NULL,NULL),(9,'sa','sa','sa','sa','','sa','sa','','2016-10-05 08:25:24','2016-10-05 08:25:24',0,'2016-10-25 10:07:38','2016-10-25 10:07:38'),(10,'Nepal','admakdn','nadns','dnsdns','dns@s.fskfn','dajdaj','fsfs','snfsj','2016-10-13 09:30:12','2016-10-11 06:30:12',0,'2016-10-25 10:32:29','2016-10-25 10:32:29');
/*!40000 ALTER TABLE `churches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `level` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `college` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `college_address` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `seats` int(11) NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `courses_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (2,'Bachelor in Engineering','Intermediate','TU','Kathmandu, Pokhara, Dharan',6,'Should be affiliated to Institute of Engineering',1,NULL,'2016-10-29 02:06:48'),(3,'Charted Accountancy','Bachelor','Indian Recognized Board','',2,'NULL',1,NULL,NULL),(4,'Bachelor in Public Health','Bachelor','IOM-TU','',5,'',1,NULL,NULL),(5,'Masters in Engineering','Masters','TU,PU,KU','',4,'',1,NULL,NULL),(6,'Bachelor in Software Engineering','Bachelor','PU','',4,'',1,NULL,NULL),(8,'Bachelor in system engineering','Bachelor','Apex College','Babarmahal, Kathmandu',5,'null',0,'2016-10-25 11:26:55','2016-10-25 11:26:55');
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_type` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scholars_id_index` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date_event` datetime NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `events_id_index` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `galleries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `galleries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `category` text NOT NULL COMMENT 'catagory of image or video',
  `iv` text NOT NULL COMMENT 'image or video',
  `image` varchar(300) NOT NULL,
  `url` varchar(1000) NOT NULL COMMENT 'for image or youtube url',
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `galleries` WRITE;
/*!40000 ALTER TABLE `galleries` DISABLE KEYS */;
INSERT INTO `galleries` VALUES (2,'A test youtube video','Featured','Video','https://img.youtube.com/vi/A19bcEVG1aE/1.jpg','A19bcEVG1aE',0,'2017-03-19 15:26:58','2017-03-15 11:37:25'),(8,'Children at Gentle Heart Children Home taking Selfie wit Arjun','Mission','Image','assets/images/gallery/1490018523.jpg','',0,'2017-03-20 08:17:03','2017-03-20 14:02:03'),(9,'GHF providing computer for a school in Sindhupalchowk','Mission','Image','assets/images/gallery/1490019140.jpg','',0,'2017-03-20 08:27:21','2017-03-20 14:12:21'),(10,'Conducting awareness programs ','Mission','Image','assets/images/gallery/1490019249.jpg','',0,'2017-03-20 08:29:10','2017-03-20 14:14:10'),(11,'Providing relief materials for earthquake victims 2015','Mission','Image','assets/images/gallery/1490019399.jpg','',0,'2017-03-20 08:31:40','2017-03-20 14:16:40');
/*!40000 ALTER TABLE `galleries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `org_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slogan` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `active_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `show_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gov_reg_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `swc_reg_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pan_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fb_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `google_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `twitter_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `linkedin_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `info_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'Prabhav','changing people, changing nepal','','','POB 556, Pokhara, Kaski, Nepal','+977 123456789','www.prabhav.org','','info@prabhav.org','270/068','30848','304485684','http://fb.com/prabhav','http://google.com/prabhav','http://twitter.com/prabhav','http://linkedin.com/prabhav',NULL,NULL),(2,'servenow\r\n','s','s','s','s','s','s','s','s','s','s','s','s','s','s','s',NULL,NULL);
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `parent_id` int(11) NOT NULL,
  `url` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES (1,'Home',0,'home');
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2014_10_12_000000_create_users_table',1),('2014_10_12_100000_create_password_resets_table',1),('2016_10_09_090542_create_blogs_table',1),('2016_10_09_090619_create_churches_table',2),('2016_10_09_090633_create_executive_boards_table',2),('2016_10_09_090649_create_events_table',2),('2016_10_09_090717_create_miscellaneous_table',2),('2016_10_09_090728_create_testimonials_table',2),('2016_10_09_090956_create_scholars_table',2),('2016_10_09_091031_create_info_table',2),('2016_10_09_091141_create_urgent_notice_table',2),('2016_10_09_091405_create_courses_table',2),('2016_10_09_095524_create_sliders_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `miscs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `miscs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `show_title` text COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `views` int(10) unsigned NOT NULL,
  `likes` int(10) unsigned NOT NULL,
  `tags` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `published` tinyint(1) NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blogs_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `miscs` WRITE;
/*!40000 ALTER TABLE `miscs` DISABLE KEYS */;
INSERT INTO `miscs` VALUES (3,'The Big Picture','the-big-picture','<p></p><p><strong>The Birth of Gentle Heart Foundation</strong></p><p>The Gentle Heart Foundation was born out of a sense of God’s heart for orphaned children of Nepal and the personal experience of the founder. The founder says that the service should originate from the heart and be implemented by the hands, this is how the name Gentle Heart Foundation came to be! He took in his first child in 2002 and after marriage in 2003 they had three boys living in their new apartment. Support for the needs of the children comes to the Foundation by their own work and gifts of friends. Today they have rented an 8 room home that provides space for 18 children. 6 others have gone on to work or further schooling. In 2009 the work expanded to children whose families are trapped by poverty, disability and/or exploitation. In 2015 it expanded further to include exploited and high risk women of Nepal.</p><p><br></p><p><strong>Our Mission</strong></p><p>“To help orphaned, underprivileged and destitute children of Nepal as well as high risk girls &amp; sexually exploited women in their need and help them to feel the fullness of life.”</p><p>Through its workers and volunteers the Gentle Heart Foundation aims to care for the rejected, be a family for the orphaned, help the helpless, provide a home for the homeless, give hope to the hopeless, and meet the basic needs of needy children &amp; exploited girls/women and offer them a better life.</p><p><strong><br></strong></p><p><strong>What We Do</strong></p><p>Gentle Heart Foundation is a nonprofit, non-governmental organization in Nepal; launched in 2002 to help orphaned and vulnerable children and high risk &amp; sexually exploited girls/women by providing them with a loving family environment within a home and working for their holistic development.</p><p><strong><br></strong></p><p><strong>Our Service and Values</strong></p><br><br><ul><li>Provide a family environment for orphaned and vulnerable children within a home.<br></li><li>Provide for the educational needs of the children through scholarships &amp; an After School Program.<br></li><li>Nurture the physical, mental, and psycho-social health and personality aspects of endangered children.<br></li><li>Provide primary health care and basic as well as technical education for the children &amp; women.<br></li><li>Run and support various community-based programs that address and facilitate the fundamental rights of the children &amp; women.<br></li><li>Involve and invite the participation of local people in activities and education regarding child development and women’s rights.<br></li><li>Run a Recovery Home for high risk and exploited girls/women that provides a safe environment for them to work on their personal recovery.<br></li><li>Provide Recovery Day Program that incorporates life skills training and teaching for high risk and exploited girls/women that will enable them to be reintegrated into society.<br></li><li>Encourage individuals to stretch out their hands to help needy children around them.<br></li><li>Create awareness of the horrors of human trafficking and how to work to combat it.&nbsp;<br></li><li>Provide vocational training for high risk girls and/or poor women through prevention programs.<br></li></ul>&nbsp;<p><strong>Our Programs</strong></p><p><br></p><p><strong>1. Children’s Programs (Children receive the benefits of all of these programs)</strong></p><br><p><strong>a. For Abandoned Children</strong><br><br>These children have no one around to care for them. Their parents may have died, been victims of civil violence or are simply untraceable.</p><p><strong>Our response: Gentle Heart Children’s Home</strong></p><br><p><strong>b. For Exploited Children:</strong><br><br>These children fall into 4 categories, although overlap between categories is common.</p><p><strong>i)&nbsp;&nbsp;Child Labor</strong></p><p>Many children work to help supply their family income, or simply because schooling is unaffordable. These children may work in such places as restaurants, factories, or family-run fields. According to UNICEF, 34% of Nepalese children fall into this&nbsp;category.</p><p><strong>Our response: Scholarships &amp; After School Program </strong></p><p><br></p><p><strong>ii)&nbsp;Child Slavery</strong></p><p>These children do domestic work, or labor for businesses such as carpet factories, brick kilns and restaurants. Many of them are sold or forced into slavery due to extreme poverty, while many others are abandoned children “taken in” by the businesses.</p><p><strong>Our response: Gentle Heart Children’s Home</strong></p><p><br></p><p><strong>iii)&nbsp;Local Sex Trade </strong></p><p>For the many children forced into the local sex industry, returning to a normal life can be very difficult due to social attitudes, or simply because they lack the skills to enter legitimate employment.</p><p><strong>Our response: Gentle Heart Children’s Home or Reintegration</strong></p><p><br></p><p><strong>iv)&nbsp;Human Trafficking </strong></p><p>Nepal has one of the world’s largest number of trafficked persons per year. Many of these cases occur by relatives and/or youngsters being tricked by promises of attractive employment overseas.</p><p><strong>Our response: Awareness campaigns</strong></p><br><br><p>&nbsp;<strong>2. Prevention Program</strong></p><p>Training in various skills such as tailoring, cosmetology etc. is provided to empower women. Timely awareness campaigns are conducted to educate women in order to prevent them from becoming victims of either the local sex trade or human trafficking.</p><p><br></p><p><strong>3. Holistic Development of exploited &amp; high risk Women </strong></p><p>Tens of thousands if not more, young Nepali women are being sexually exploited across Nepal in cabin restaurants, tea shops, dance bars, brothels and on the streets. In India and abroad hundreds of thousands of young Nepali women (if not more) are being sexually exploited and held against their will. With this in mind, Gentle Heart Foundation (GHF) offers long term Recovery Based Programs for women &amp; female youth who have been sexually exploited/trafficked who have chosen to leave the sex trade, or escaped the brothels, or were forced to leave because of age or illness. These Programs are also offered to women and female youth who are at risk of being sexually exploited or trafficked. &nbsp;The long term social return of these Programs is that the women who go through them will able to reintegrate into their communities and become productive members of society.</p><p>The Long Term Recovery Based Program is organized into the following phases with the constituent parts of each phase spelled out below the heading.</p><p><strong>a)&nbsp;PHASE I </strong></p><br><p>i. Housing for moms &amp; kids and a Parent Support Center.</p><p>ii. Housing for single women - Frontline House</p><p>iii. Recovery Day Program and Beginning Vocational &amp; Educational Development.</p><p>iv. Housing for Single women from KTM/for women coming back to Nepal from the Rescue Mission in India</p><p>v. Childcare and education for the children of the women involved in Phase I and II Programs who are over age 3.</p><p><br></p><p><strong>b)&nbsp;PHASE II </strong></p><p>i. Transitional Housing for Women with or without children</p><p>ii. Advanced Day Program for Vocational &amp; Educational Development (which includes job shadowing, employment training, paid work experience within or outside GHF, skill development, education and set up in micro enterprises – &nbsp;for a maximum of 6 years for women involved in Transitional Housing).</p><p><br></p><p><strong>c)&nbsp;PHASE III Followcare Program </strong></p><p>i. All Graduated Participants will be given ongoing personal monitoring to ensure that they are achieving their goals and living safe and productive lives.</p><p><br></p><p><strong>d)&nbsp;PHASE IV Servant Leadership Program</strong></p><p>i. &nbsp;Opportunities are given within Gentle Heart Foundation for successful participants to mentor and encourage current participants in their recovery journey.</p><p><br></p><p><strong>4. Relief or Emergency Response</strong></p><p>GHF is always there to respond the emergency need of the people !</p><br><p></p>',0,0,NULL,0,'',0,'2017-03-19 08:59:27','2017-03-19 09:13:58'),(4,'Our Mission','our-mission','<p></p><p>\"To help the Orphaned, underprivileged and destitute children of Nepal as well as high risk girls in their need and help them to feel the fullness of life.<br>Provide them loving and family environment within the home and work for their spiritual, mental, physical, social and educational development.\"<br><br></p><p>We aim to care the rejected, be a family for the orphan, help the helpless, provide home for the homeless, give hope to the hopeless, and meet the basic<br>needs of needy children and help the poor and needy widows for their better living.<br></p><p><br>God is not unjust; He will not forget your work and the love you have shown Him as you have helped His people and continue to help them. -  &nbsp; <strong>Hebrews 6:10</strong><br></p><p>Religion that God our Father accepts as pure and faultless is this: to look after orphans and widows in their distress and to keep oneself from being polluted by the world. - <strong>James 1:27</strong></p><p></p>',0,0,NULL,0,'',0,'2017-03-19 09:17:21','2017-03-19 09:18:28'),(5,'Career Opportunities','career-opportunities','<p>There is no vacancies at this moment. Please keep watching.</p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p>',0,0,NULL,0,'',0,'2017-03-19 09:25:59','2017-03-19 09:28:04'),(6,'How can you help us?','join-us','<p></p><p>Gentle Heart is presently supported mainly by Arjun\'s personal income from his 7-to-7 job, as well as sporadic contributions by our friends- both in cash and kind. For this reason, out most crucial need at the moment is a regular inflow of finances to allow Arjun to devote more of his time to fathering the children at GH Children\'s Home and realising The Big Picture. The following are some ways you can play your part:</p><br><p><strong>Sponsor a child or children</strong></p><p>Due to the increase cost of daily commodities, paying house rent, providing proper accommodation, hygienic food, good education, medication, clothing etc. for children at Gentle Heart Children\'s Home is very challenging for us. So we desperately need the regular Sponsor, if you want to the cost breakdown, please let us know and we will give you the details and needed information.</p><br><p><strong>What you will get:</strong></p><p>- 3 Personal updates</p><p>A report will be emailed to you at the end of each term,providing the latest photograph and updates on your child\'s progress,</p><p>- 1 General ReportThis will summarise updates and give an overview of the GH Children\'s Home and other GHF efforts</p><p><br><strong>Sponsor a child or children now</strong></p><p>You have an opportunity to make a difference in the lives of children of Nepal today !</p><br><p><strong>Give a donation</strong></p><p>You can make a one-off contribution in any of the following ways:<br><br><br><br><strong>Financial</strong><br><br>If you are willing to support this ministry financially, please email us at<a target=\"_blank\" rel=\"nofollow\">ghchnepal@mail.com.np</a> and contact us via email for our banking information</p><br><p><strong>In Kind</strong><br><br>We welcome donations of books, clothes toys and similar gifts. If you wish to contribute in this way, please email us at <a target=\"_blank\" rel=\"nofollow\">ghchnepal@mail.com.np</a></p><p><br></p><p><strong>Volunteer</strong></p><p>Although we do not run any structured volunteering schemes, we would be happy to have you come over and help out at our home. There are loads of ways to help, from tutoring schoolwork and teaching music lessons to washing up and helping put the kids to bed. Please email us at ghchnepal@mail.com.np if you are interested !</p><p><br></p><p><strong>Pray</strong></p><p>For the children, the other family members, the scholarship students, our plans and most importantly, for the many suffering children in Nepal.</p><br><p><strong>Spread the word</strong></p><p>This is perhaps the easiest way to help, but it\'s also highly important. Let your friends know, by word of mouth, or by any means !</p><br><br><p></p>',0,0,NULL,0,'',0,'2017-03-19 09:30:31','2017-03-19 09:32:41');
/*!40000 ALTER TABLE `miscs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES ('pokharelsuresh@yahoo.com','66ead88bb96d2fa98b0565a646a346263328e5f367670068220fe29eb780504c','2017-03-22 07:34:42');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preferences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pref_name` varchar(400) COLLATE utf8_unicode_ci NOT NULL,
  `data1` varchar(400) COLLATE utf8_unicode_ci NOT NULL,
  `data2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `info_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `preferences` WRITE;
/*!40000 ALTER TABLE `preferences` DISABLE KEYS */;
INSERT INTO `preferences` VALUES (1,'last_backup_date','2017-05-03 07:36:37',NULL,'2017-04-30 23:40:31','2017-05-03 01:51:37');
/*!40000 ALTER TABLE `preferences` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `programs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `highlight` text COLLATE utf8_unicode_ci,
  `views` int(10) unsigned NOT NULL,
  `likes` int(10) unsigned NOT NULL,
  `tags` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `published` tinyint(1) NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `thumb` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blogs_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `programs` WRITE;
/*!40000 ALTER TABLE `programs` DISABLE KEYS */;
INSERT INTO `programs` VALUES (1,'Gentle Heart Children\'s Home','99','<p></p><p>Gentle Heart Foundation always aims on providing special care for the orphaned, underprivileged and vulnerable children of Nepal. GHF started a Home in 2002 to provide the family environment for the children and is presently located in a rented 10-room house in Kathmandu, Nepal. The 18 sons and daughters and the youngest is 6 years old and are all enrolled in English-medium schools. We also have 10 others who have moved on to independence and are now in further education or employment.</p><p>We give the utmost attention to developing these children holistically to help them grow into well-rounded and independent adults. Hence, we keep close tabs on their schoolwork and have prep-times daily. The children are encouraged to participate actively in extra-curricular activities, and have responsibilities around the house proportionate to their maturity. We also have time set aside every morning and evening for personal and corporate prayer and bible study.</p><p>We are getting many request to help the children who are in desperate need, living without family and looking for someone\'s care and love, by knowing the utmost need of such children, we strongly feel the need of another Home where we can help in better way by keeping smaller in numbers. So, we are praying for the needed resources for setting up and running the two different Homes !</p><br><p><em><strong>GHF is looking for Partnership for this program to run smoothly.</strong></em></p><br><p></p>',NULL,74,0,NULL,1,'assets/images/program/1489933335.JPG','assets/images/program/thumb_1489933335.JPG',0,'2017-03-15 01:17:06','2017-03-20 08:32:06'),(2,'Recovery Programs','95','<p></p><p>Tens of thousands if not more, young Nepali women are being sexually exploited across Nepal in cabin restaurants, dance bars, brothels and on the streets. In India and abroad hundreds of thousands of young Nepali women (if not more) are being sexually exploited and held against their will.</p><p>It is very difficult to help these women while they are being held captive however someday all of them will be kicked out, forced to leave or will escape their captors. At this time it is critical that these women are immediately given a place to begin the long healing process. It is critical that they are given every kind of support service necessary to recover and start a new life.</p><p>Gentle Heart Foundation aims to provide a way out for young women that are able to escape the sex trade and offer them a viable solution for their recovery and sustainability.</p><p>GHF has adopted the SA Foundation Program Model for \"Recovery Base Programs\" . The SA Foundation is Christian based program widely recognized as one of the few programs worldwide meeting the specific needs of sexually exploited/trafficked women with or without children. The SA Foundation Program Model has been replicated in Canada, the U.S, Asia and Europe.</p><p><br></p><p><em><strong>The SAF is providing funding for this program.</strong></em></p><br><br><p>&nbsp;</p><br><br><p></p>',NULL,5,0,NULL,0,'assets/images/program/empty','assets/images/program/thumb_empty',0,'2017-03-19 08:43:01','2017-03-20 07:43:02'),(3,'Scholarships','90','<p></p><p>We give grants for children to attend local schools. Fees are paid directly to the schools, and other needs such as uniform and stationery are provided in kind. This way, we avoid the potential problem of parents misusing funds.</p><p>We presently support 125 children who are in desperate need of education help in different parts of Nepal, and visit them at the end of every term to keep tabs on their progress. We are happy to inform you that they all are doing well. It is such a joy to see the happy faces :) While we met to their teachers, they were very impressed with the mission of GHF. Thank you for your prayers.</p><p>&nbsp;</p><p><em><strong>GHF is looking for Partnership for this program to run smoothly.</strong></em></p><br><br><p>&nbsp;</p><br><p></p>',NULL,1,0,NULL,0,'assets/images/program/1489934220.JPG','assets/images/program/thumb_1489934220.JPG',0,'2017-03-19 08:52:01','2017-03-31 10:01:52'),(4,'Vocational training and micro loans','85','<p></p><p>These would help improve employ ability  and potentially open up opportunities for small business. Our plan is to begin with having some of the older children in the Children\'s Home learn vocational skills, and then teach them to these women. Not only would this help the women concerned, but the \"teachers\" would also gain skills and have an opportunity to serve. Training could include skills such as knitting, tailoring, making handicrafts etc.</p><p>These are for cases where the trained women wish to start a small business as a result of their new skill-such as by making and selling handicrafts. We can help them with the initial cost by giving small loans at very low interest rates.</p><br><br><p>&nbsp;</p><br><br><p>&nbsp;</p><br><br><p><em><strong>GHF is looking for Partnership for this program to run smoothly.</strong></em></p><br><br><p>&nbsp;</p><br><br><p></p>',NULL,2,0,NULL,0,'assets/images/program/1489934343.JPG','assets/images/program/thumb_1489934343.JPG',0,'2017-03-19 08:54:03','2017-03-20 07:42:56'),(5,'Trafficking Awareness Campaigns','80','<p>This is especially needed in remote areas, where similar efforts by other social workers are minimal or non-existent. Our campaign structure will include working with local governments at the village and regional levels to spread information about the deceptive practices of traffickers. In addition, we are exploring the possibility of working with networks of churches. The idea is to have an audience with ministers at conferences, and equip them to spread the word in their respective villages. Finally, we are hoping to conduct events and help set up social clubs at the village level which will continually help raise awareness of the issue among parents and youngsters.<br><br></p><p>&nbsp;</p><br><br><p>&nbsp;</p><br><br><p><em><strong>GHF is looking for Partnership for this program to run smoothly.</strong></em></p><br><br><p>&nbsp;</p><br><br><p></p>',NULL,1,0,NULL,0,'assets/images/program/1489934401.jpg','assets/images/program/thumb_1489934401.jpg',0,'2017-03-19 08:55:02','2017-03-20 07:42:28'),(6,'Gender Empowerment and Income generators','75','<p>This project is addressed to abandoned or widowed women who cannot support themselves adequately.<br><br>Donating income generators such as a pair of cattle can help increase a woman\'s income consistently and over the long term. Goats, for instance, could be bred for sale.<br><br></p><p><em><strong>GHF is looking for Partnership for this program to run smoothly.</strong></em></p><p></p>',NULL,4,0,NULL,0,'assets/images/program/empty','assets/images/program/thumb_empty',0,'2017-03-19 08:55:36','2017-03-31 10:02:00'),(7,'Reintegration','70','<p>The idea behind this project is to help children who want to escape the socioeconomic, psychological and spiritual clutches of the sex trade in order to lead normal lives. This may be difficult due to social attitudes concerning their backgrounds, or simply because they lack the skills to enter employment. We hope to provide biblical counselling for the affected people and their families, as well as vocational training to help them get work.<br></p>',NULL,1,0,NULL,0,'assets/images/program/empty','assets/images/program/thumb_empty',0,'2017-03-19 08:56:04','2017-03-20 07:42:06'),(8,'After School Program','65','<p></p><p><em><strong>GHF started this program by knowing the following reality:</strong></em></p><ul>&nbsp; <li>After-school programs keep children, especially girls safe and protect them from negative and unsafe behaviors.&nbsp;</li><li>Improves personality and maturity&nbsp;</li><li>After school programs have an impressive influence on preventing these girls from experimenting with drugs and other deviant behavior. This is simply because students are enjoying a productive activity and are being supervised during their attendance in the after school program.</li></ul><p>Programs and tutoring keep children away from trouble</p><br>&nbsp;<blockquote><p>High-risk teen girls conduct transpires most often after school. This is a time when these girls are out of school and parents or guardians are still working. Unwatched and on their own, girls can get involved in a number of activities that may not be appropriate, or even participate in activities that can actually be very dangerous. That\'s when bad things can happen ... in an instant ... unexpected.</p><br></blockquote><ul><br>&nbsp; <li><p>Provides supervision for parents who cannot regularly be with their offspring</p></li></ul><ul><li><p>GHF want to create real \'community school\' that serve the entire community through these girls</p></li><li><p>Giving the opportunity for creative activity i.e. writings, poem, speech, drawing, singing etc.&nbsp;</p></li></ul><ul><li><p>Provide activities that support socialization with peers.</p></li><li><p>GHF aims to support and complement classroom learning by emphasizing social, emotional and physical development for these girls.&nbsp;</p></li></ul><ul><li><p>Help working parents who are poor of the poorest.</p></li></ul><br><p><strong>Having said these, after school program is running for:</strong></p><blockquote><ul><br>&nbsp; <li><p>Prevent from crime, drugs &amp; exploitation/trafficking.</p>&nbsp;&nbsp;</li><li><p>Social-emotional development i.e. self-esteem, initiative, leadership skills etc.</p></li>&nbsp;&nbsp;<li><p>Better education performance for girls to provide equal opportunity&nbsp;</p><br>&nbsp;</li></ul></blockquote><p><em><strong>GFC is providing part of the amount for this program and still looking for additional needed funding to carry on this project.</strong></em></p><br><br><p><br></p><p></p>',NULL,3,0,NULL,0,'assets/images/program/1489934588.jpg','assets/images/program/thumb_1489934588.jpg',0,'2017-03-19 08:58:08','2017-03-20 07:32:02');
/*!40000 ALTER TABLE `programs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scholars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scholars` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `organization` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dob` date DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scholars_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scholars` WRITE;
/*!40000 ALTER TABLE `scholars` DISABLE KEYS */;
INSERT INTO `scholars` VALUES (1,'Shova & Arjun',NULL,NULL,'assets/images/scholars/1490017080.jpg','2017-03-20',0,'2017-03-20 07:53:00','2017-03-20 07:53:00'),(15,'Shoana Dhakal',NULL,NULL,'assets/images/scholars/1490017006.jpg','2007-06-01',0,'2017-03-20 07:51:47','2017-03-20 07:51:47'),(16,'Markus Tamang',NULL,NULL,'assets/images/scholars/1490017039.jpg','2009-07-08',0,'2017-03-20 07:52:19','2017-03-20 07:52:19'),(18,'Mandira Gotame',NULL,NULL,'assets/images/scholars/1490017185.jpg','2006-11-04',0,'2017-03-20 07:54:45','2017-03-20 07:54:45'),(19,'Mukul Kunwar',NULL,NULL,'assets/images/scholars/1490017207.jpg','2007-10-30',0,'2017-03-20 07:55:08','2017-03-20 07:55:08'),(20,'Bijay Tamang',NULL,NULL,'assets/images/scholars/1490017234.jpg','2006-11-28',0,'2017-03-20 07:55:34','2017-03-20 07:55:34'),(21,'Norbu Tamang',NULL,NULL,'assets/images/scholars/1490017264.jpg','2006-12-01',0,'2017-03-20 07:56:04','2017-03-20 07:56:04'),(22,'Biraj Bhatta',NULL,NULL,'assets/images/scholars/1490017289.jpg','2006-08-17',0,'2017-03-20 07:56:29','2017-03-20 07:56:29'),(23,'Sristi Thapa Magar',NULL,NULL,'assets/images/scholars/1490017347.jpg','2006-10-09',0,'2017-03-20 07:57:27','2017-03-20 07:57:27'),(24,'Puspa Praja',NULL,NULL,'assets/images/scholars/1490017377.jpg','2005-11-04',0,'2017-03-20 07:57:57','2017-03-20 07:57:57'),(25,'Rejina Giri',NULL,NULL,'assets/images/scholars/1490017402.jpg','2004-06-19',0,'2017-03-20 07:58:23','2017-03-20 07:58:23'),(26,'Abhishek Rai',NULL,NULL,'assets/images/scholars/1490017435.jpg','2005-11-03',0,'2017-03-20 07:58:55','2017-03-20 07:58:55'),(27,'Sunita Gurung',NULL,NULL,'assets/images/scholars/1490017468.jpg','2001-07-16',0,'2017-03-20 07:59:28','2017-03-20 07:59:28'),(28,'Eunice Dhakal',NULL,NULL,'assets/images/scholars/1490017495.jpg','2004-06-19',0,'2017-03-20 07:59:55','2017-03-20 07:59:55'),(29,'Sujan Sapkota',NULL,NULL,'assets/images/scholars/1490017524.jpg','1994-05-17',0,'2017-03-20 08:00:24','2017-03-20 08:00:24'),(30,'Elisha Dangi',NULL,NULL,'assets/images/scholars/1490017551.jpg','2002-09-18',0,'2017-03-20 08:00:52','2017-03-20 08:00:52'),(31,'Umesh Karki',NULL,NULL,'assets/images/scholars/1490017579.jpg','1999-02-17',0,'2017-03-20 08:01:19','2017-03-20 08:01:19'),(32,'Sristi Tamang',NULL,NULL,'assets/images/scholars/1490017614.jpg','2000-09-13',0,'2017-03-20 08:01:55','2017-03-20 08:01:55'),(33,'Ruben Khadka',NULL,NULL,'assets/images/scholars/1490017638.jpg','2001-09-23',0,'2017-03-20 08:02:18','2017-03-20 08:02:18');
/*!40000 ALTER TABLE `scholars` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sliders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sliders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `desc_1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `desc_2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `desc_3` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `refferal_link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `thumbnail` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `isActive` tinyint(1) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sliders_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sliders` WRITE;
/*!40000 ALTER TABLE `sliders` DISABLE KEYS */;
INSERT INTO `sliders` VALUES (6,'assets/images/sliders/1489916725.jpg','Many children are expressing their happiness as they got the privileged for their study','This is just another caption','','','assets/images/sliders/thumbnail_1489916725.jpg',1,0,'2017-03-14 04:50:27','2017-03-19 04:00:26'),(7,'assets/images/sliders/1489916762.jpg','Gentle Heart Children Home - Family Photo','rimarily focuses on web development tutorial as well as in SAP FIC','','','assets/images/sliders/thumbnail_1489916762.jpg',1,0,'2017-03-15 06:34:15','2017-03-19 04:01:02');
/*!40000 ALTER TABLE `sliders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `subscribes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscribes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `group` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'subscribed',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `subscribes` WRITE;
/*!40000 ALTER TABLE `subscribes` DISABLE KEYS */;
INSERT INTO `subscribes` VALUES (1,'sa@gmail.com','Undefined','Subscribed','2016-11-10 04:07:58','2016-11-10 09:52:58'),(2,'suresh.wrc@gmail.com','Undefined','Subscribed','2016-11-10 04:12:11','2016-11-10 09:57:11'),(3,'suresh.wrc@gmail.com','Undefined','Subscribed','2016-11-10 05:19:56','2016-11-10 11:04:56'),(4,'suresh.wrc@gmail.com','Undefined','Subscribed','2016-11-10 05:20:31','2016-11-10 11:05:31'),(5,'sa@sa.ca','Undefined','Subscribed','2016-11-10 05:29:23','2016-11-10 11:14:23'),(6,'dsa@dsa.dsa','Undefined','Subscribed','2016-11-10 05:30:46','2016-11-10 11:15:46'),(7,'gfa@ga.kd','Undefined','Subscribed','2016-11-10 05:31:12','2016-11-10 11:16:12'),(8,'sa@ds.hf','Undefined','Subscribed','2016-11-10 05:32:05','2016-11-10 11:17:05'),(9,'sad@hj.hg','Undefined','Subscribed','2016-11-10 05:32:51','2016-11-10 11:17:51');
/*!40000 ALTER TABLE `subscribes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `testimonials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testimonials` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `designation` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `organization` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `testimonials_id_index` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `testimonials` WRITE;
/*!40000 ALTER TABLE `testimonials` DISABLE KEYS */;
/*!40000 ALTER TABLE `testimonials` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `urgents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `urgents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `referral_link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `urgents_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `urgents` WRITE;
/*!40000 ALTER TABLE `urgents` DISABLE KEYS */;
INSERT INTO `urgents` VALUES (37,'sasasasa','nayalink-aganicxa',0,0,'2016-10-28 09:12:22','2016-10-28 22:31:41'),(39,'today','today',0,0,'2016-10-28 22:03:17','2016-10-28 22:03:17');
/*!40000 ALTER TABLE `urgents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `last_active` datetime NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Suresh Pokharel','suresh.wrc@gmail.com','$2y$10$PhXtcUHP5qReteMxxMa60u5aUpejuFBmX8jc2p9QPd7Y3Y.YGUPom','9846333110','Master','assets/images/admin/users/male3.png',1,'0000-00-00 00:00:00','MTUbR9NPjHFF9kfGvMraSpRYgYcOBDl6gMRGQ7WxHaj9qyJyrbLRh7JIkqon','2016-10-22 08:48:09','2017-05-03 01:04:12'),(2,'Sujan Sapkota','sujan@gmail.com','$2y$10$hFpGcElTt0C.8iLlMwkgzuMfEA9dVt4eRGR1pbkd9xQCPKlK3g6UC','984621542','General','assets/images/admin/users/male3.png',1,'0000-00-00 00:00:00',NULL,'2016-10-25 13:18:22','2017-02-17 09:01:49'),(3,'ramesh','pokharelsuresh@yahoo.com','$2y$10$RffmGS7Btbm8K9AvGhNeruyt4ChIGopzZcYM2N9lyi9rZmiwrHZDS','45455454','General','assets/images/admin/users/male1.png',0,'0000-00-00 00:00:00',NULL,'2016-10-27 04:08:01','2016-10-27 04:08:01'),(4,'sa','sa@sa.sa','$2y$10$flflY0yo6w8utX7yQgyOUeD6enK97Kcqg49.DqUof3xXwanCiyNna','sasa','General','assets/images/admin/users/male2.png',0,'0000-00-00 00:00:00',NULL,'2016-10-29 12:04:13','2016-10-29 12:04:13');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

