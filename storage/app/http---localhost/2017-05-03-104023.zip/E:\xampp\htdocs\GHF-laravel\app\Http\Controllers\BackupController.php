<?php

namespace App\Http\Controllers;
use Auth;
use App\Preference;
use Illuminate\Http\Request;
use Artisan;
use Carbon\Carbon;
use App\Http\Requests;

class BackupController extends Controller
{
    public function fullDownload(){
    	Artisan::call('backup:run');
    }

     public function changeLastBackupDate (Request $request){
        if (Auth::check()){
        		$pref_id=1; //last backup date is always kept with id 1 and it is not changeable                   
                $pref = new Preference;
                $pref = array(
                 'pref_name' => "last_backup_date",
                 'data1' => Carbon::now(),
                );

                Preference::where('id',$pref_id)->update($pref);
                //return Redirect::back()->with('success_message','Event updated successfully');
                } 
        else return redirect('admin/login')->with('flash_msg', 'You have to login first');
    } 
}
