<?php

namespace App\Providers;

use Storage;
use League\Flysystem\Filesystem;
use Dropbox\Client as DropboxClient;
use League\Flysystem\Dropbox\DropboxAdapter;
use Illuminate\Support\ServiceProvider;

class DropboxFilesystemServiceProvider extends ServiceProvider
{
    public function boot()
    {
        Storage::extend('dropbox', function ($app, $config) {
            $client = new DropboxClient($config['0jMXvhtOVgAAAAAAAAADCV1GsUJojer4Z5hyAsbYETDqS33tJAuhSC4_XHOE1X-s'], $config['   
    sxwv5mhj6k52dg7']);
            return new Filesystem(new DropboxAdapter($client));
        });
    }

    public function register()
    {
        //
    }
}